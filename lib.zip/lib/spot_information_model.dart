import 'package:flutter/material.dart';

class SpotInformationModel extends ChangeNotifier {

  Map spotInfo = {};
  List reviewsList = [];
  String imageUrl = "";
  void updateSpotInfo(data) {
    spotInfo = data;
    notifyListeners();
  }
  void updateImageUrl(data) {
    imageUrl = data;
    notifyListeners();
  }
  void updateReviewsList(data) {
    reviewsList = data;
    notifyListeners();
  }


}