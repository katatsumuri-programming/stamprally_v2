import 'package:flutter/material.dart';

class ProjectInformationPageModel extends ChangeNotifier {
  Map<String, dynamic> stamprallyInfo = {};
  String imageUrl = "";
  List spotsList = [];
  List imageUrlList = [];

  void updateStamprallyInfo(data) {
    stamprallyInfo = data;
    notifyListeners();
  }
  void updateSpotList(data) {
    spotsList = data;
    notifyListeners();
  }
  void updateImageUrl(data) {
    imageUrl = data;
    notifyListeners();
  }
  void updateImageUrlList(data) {
    imageUrlList = data;
    notifyListeners();
  }
}