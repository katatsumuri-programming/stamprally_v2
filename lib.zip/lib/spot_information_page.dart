import "package:flutter/material.dart";
import 'package:cached_network_image/cached_network_image.dart';
import 'package:stamprally_v2/main.dart';
import 'package:provider/provider.dart';
import 'package:stamprally_v2/spot_information_model.dart';

class SpotInformationPage extends StatefulWidget {

  // final Map spotInfo;
  // final String imageUrl;
  // final List reviewsList;

  const SpotInformationPage({super.key});

  @override
  State<SpotInformationPage> createState() => _SpotInformationPageState();
}

class _SpotInformationPageState extends State<SpotInformationPage>
     with SingleTickerProviderStateMixin  {

  late Map _spotInfo = {};
  late List _reviewsList = [];
  late int? _tabIndex = 0;
  String _imageUrl = '';
  TabController? _tabController;
  bool imgVisibility = true;

  @override
  void initState() {
    super.initState();
    _reviewsList = [];
    _tabController = TabController(vsync: this, length: 3);
    _tabController!.addListener(_handleTabChange);

    setState(() {
      _spotInfo = Provider.of<SpotInformationModel>(context, listen: false).spotInfo;

      _reviewsList = Provider.of<SpotInformationModel>(context, listen: false).reviewsList;
    });
  }
  void _handleTabChange() {
    if (_tabIndex != _tabController?.index) {
      if (_tabController?.index == 0) {
        imgVisibility = true;
      } else {
        imgVisibility = false;
      }
      if (_tabController?.index == 1) {
        Future(() async {
          print("AA");
          _reviewsList = _reviewsList.isEmpty ? await getData({'type':'get_reviews', 'id':_spotInfo["id"].toString(), 'limit_start':'0', 'limit_end':'10'}) : _reviewsList;
          Provider.of<SpotInformationModel>(context, listen: false).updateReviewsList(_reviewsList);
        });
      }
    }
    _tabIndex = _tabController?.index;
    setState(() {});
  }

  @override
  void dispose() {
    _tabController!.removeListener(_handleTabChange);
    _tabController!.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 1,
        backgroundColor: Colors.white,
        centerTitle: true,
        title: Image.asset(
          'images/appBarImage.png',
          height: 38,
        ),
        actions: [
          Visibility(
            visible: true,
            child: Padding(
              padding: EdgeInsets.all(10),
              child: ElevatedButton(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal:5),
                  child: const Text(
                    'Check!',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold
                    )
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  foregroundColor: Colors.white,
                  shape: const StadiumBorder(),
                ),
                onPressed: () {},
              ),
            ),
          ),

        ],
      ),
      body: Consumer<SpotInformationModel>(builder: (context, model, child) {
          return Container(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Visibility(
                    visible: imgVisibility,
                    child: model.imageUrl != ''
                      ? Image(image: CachedNetworkImageProvider(model.imageUrl))
                      : const Center(child:CircularProgressIndicator()),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    model.spotInfo["title"] != null
                      ? model.spotInfo["title"]
                      : "...",
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),


                  // タブバー
                  TabBar(
                    controller: _tabController,
                    tabs: const [
                      Tab(text: '概要'),
                      Tab(text: '口コミ'),
                      Tab(text: '地図'),
                    ],
                  ),
                  // タブビュー
                  Expanded(
                    child: TabBarView(
                      physics: NeverScrollableScrollPhysics(),
                      controller: _tabController,
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(5.0),
                          child: Column(
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(8),
                                child: Text(
                                  model.spotInfo["explanation"] != null
                                    ? model.spotInfo["explanation"]
                                    : "...",
                                  style: TextStyle(
                                    fontSize: 13,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 8,),
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Column(
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.all(3),
                                      child: Row(
                                        children: [
                                          Icon(Icons.location_on, color: Colors.black54),
                                          const SizedBox(width: 8,),
                                          Text(
                                            model.spotInfo["address"] != null
                                              ? model.spotInfo["address"]
                                              : "...",
                                          )
                                        ],
                                      ),
                                    ),
                                    Divider(),
                                    Padding(
                                      padding: const EdgeInsets.all(3),
                                      child: Row(
                                        children: [
                                          Icon(Icons.web, color: Colors.black54),
                                          const SizedBox(width: 8,),
                                          Text(
                                            model.spotInfo["website"] != null
                                              ? model.spotInfo["website"]
                                              : "http://example.com",
                                          )
                                        ],
                                      ),
                                    ),
                                    Divider(),
                                    Padding(
                                      padding: const EdgeInsets.all(3),
                                      child: Row(
                                        children: [
                                          Icon(Icons.schedule, color: Colors.black54),
                                          const SizedBox(width: 8,),
                                          Text(
                                            model.spotInfo["openHours"] != null
                                              ? model.spotInfo["openHours"]
                                              : "...",
                                          )
                                        ],
                                      ),
                                    ),
                                    Divider(),
                                    Padding(
                                      padding: const EdgeInsets.all(3),
                                      child: Row(
                                        children: [
                                          Icon(Icons.currency_yen, color: Colors.black54),
                                          const SizedBox(width: 8,),
                                          Text(
                                            model.spotInfo["admissionFee"] != null
                                              ? model.spotInfo["admissionFee"]
                                              : "...",
                                          )
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              )

                            ],
                          ),
                        ),
                        ListView.separated(
                          itemCount: model.reviewsList.length,
                          itemBuilder: (context, int index) {
                            return Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      Row(children: [
                                        for (int i = 0; i < 5; i++)
                                          Icon(
                                            Icons.star,
                                            color: (i < model.reviewsList[index]["star"].round()) ? Colors.orange : Colors.grey,
                                            size: 20,
                                          )
                                      ],),
                                      SizedBox(width: 10,),
                                      Text(model.reviewsList[index]["star"].toString(), style: TextStyle(fontSize: 18),),
                                    ]
                                  ),
                                  SizedBox(height: 2,),
                                  Text(
                                    model.reviewsList[index]["title"],
                                    style: TextStyle(
                                      fontSize: 17,
                                      fontWeight: FontWeight.bold
                                    ),
                                  ),
                                  SizedBox(height: 8,),
                                  Text(
                                    model.reviewsList[index]["message"]
                                  )
                                ]
                              ),
                            );
                          },
                          separatorBuilder: (context, index) {
                            return const Padding(
                              padding: EdgeInsets.all(10),
                              child: Divider(
                                height: 1,

                              ),
                            );
                          },
                        ),
                        Container(child:Text("ここにマップをのせる"), color: Colors.red,)
                      ],
                    ),
                  ),


              ],
            ),
          );
        }
      ),
    );
  }
}