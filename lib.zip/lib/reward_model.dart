import 'package:flutter/material.dart';

class RewardModel extends ChangeNotifier {

  Map rewardInfo = {};
  String imageUrl = "";
  void updateRewardInfo(data) {
    rewardInfo = data;
    notifyListeners();
  }
  void updateImageUrl(data) {
    imageUrl = data;
    notifyListeners();
  }

}