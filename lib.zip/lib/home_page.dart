import 'package:flutter/material.dart';
import 'package:stamprally_v2/project_information_page.dart';
import 'package:stamprally_v2/project_information_page_model.dart';
import 'package:stamprally_v2/post_page.dart';
import 'package:stamprally_v2/spot_information_page.dart';
import 'package:stamprally_v2/spot_information_model.dart';
import 'package:stamprally_v2/main.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:provider/provider.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {

  int stampNum = 10;
  List spots_info = [];
  List<String> images = [];
  List stampRallies = [];
  List timeLine = [];
  List<Map<String, dynamic>> genres = [{"name":"スタンプラリー", "isCheck":false}, {"name":"スポット", "isCheck":false}, {"name":"グルメ", "isCheck":false}, {"name":"フォト", "isCheck":false}];
  @override
  void initState() {
    super.initState();
    Future(() async {
      spots_info = await getData({'type':'get_timeline_spots', 'lon':'135', 'lat':'36', 'limit_start':'0', 'limit_end':'10'});

      // print(timeLine);
      for (var i = 0; i < spots_info.length; i++) {
        spots_info[i]["is_stamp_rally"] = false;
        if (!(stampRallies.contains(spots_info[i]['stamp_rally'].toString()))) {
          stampRallies.add(spots_info[i]['stamp_rally'].toString());
        }
      }
      timeLine = [...spots_info];
      stampRallies = await getData({'type':'get_stamprally_info', 'id':stampRallies});
      var k = 0;
      for (var i = 0; i < spots_info.length; i++) {
        print(i);
        for (var j = 0; j < stampRallies.length; j++) {

          if (spots_info[i]['stamp_rally'] == stampRallies[j]["id"]) {
            stampRallies[j]["is_stamp_rally"] = true;
            timeLine.insert(i, stampRallies[j]);
            k++;
          }
        }
      }

      for (var i = 0; i < timeLine.length; i++) {
        images.add(await getImageUrl(timeLine[i]['image']));
      }
      print(timeLine);

      setState(() {});
      // print(await getData({'type':'get_reviews', 'id':'1', 'limit_start':'0', 'limit_end':'10'}));
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 1,
        backgroundColor: Colors.white,
        centerTitle: true,
        title: Image.asset(
          'images/appBarImage.png',
          height: 38,
        ),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(10),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 20),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Colors.white,
                boxShadow: const [
                  BoxShadow(
                    color: Colors.grey, //色
                    spreadRadius: 0,
                    blurRadius: 5,
                    offset: Offset(1, 1),
                  ),
                ],
              ),
              child: Row(
                children: [
                  const Text(
                    "合計スタンプ",
                    style: TextStyle(
                      fontSize: 16
                    ),
                  ),
                  const Spacer(),
                  Text(
                    stampNum.toString(),
                    style: const TextStyle(
                      fontSize: 35,
                      fontWeight: FontWeight.bold,
                      color: Colors.blue
                    ),
                  )
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: TextField(
              decoration: InputDecoration(
                prefixIcon: const Icon(Icons.search),
                contentPadding: const EdgeInsets.all(10),
                hintText: '検索',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                )

              ),
            ),
          ),

          Padding(
              padding: const EdgeInsets.only(left: 10, right: 10, bottom: 10),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    for (var i = 0; i < genres.length; i++)
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal:5),
                        child: InkWell(
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(999999),
                              border: Border.all(color: genres[i]['isCheck'] ? Colors.blue : Colors.black54),
                              color: genres[i]['isCheck'] ? Colors.lightBlue.withOpacity(0.1) : Colors.white,
                            ),
                            child: Padding(
                              padding: const EdgeInsets.symmetric(vertical:6, horizontal:15),
                              child: Text(
                                genres[i]['name'],
                                style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold,
                                  color: genres[i]['isCheck'] ? Colors.blue : Colors.black87,
                                ),
                              ),
                            ),
                          ),
                          onTap: () async {
                            if (!genres[i]["isCheck"]) {
                              genres[i]["isCheck"] = true;

                            } else {
                              genres[i]["isCheck"] = false;
                            }
                            List tags = [''];
                            genres.forEach((value) {
                              if (value['isCheck']) {
                                tags.add(value['name']);
                              }
                            });
                            if (tags.length > 1) {
                              spots_info = await getData({'type':'get_timeline_spots', 'lon':'135', 'lat':'36', 'limit_start':'0', 'limit_end':'10', 'tag':tags});
                            } else {
                              spots_info = await getData({'type':'get_timeline_spots', 'lon':'135', 'lat':'36', 'limit_start':'0', 'limit_end':'10'});
                            }


                            // print(timeLine);
                            for (var i = 0; i < spots_info.length; i++) {
                              spots_info[i]["is_stamp_rally"] = false;
                              if (!(stampRallies.contains(spots_info[i]['stamp_rally'].toString()))) {
                                stampRallies.add(spots_info[i]['stamp_rally'].toString());
                              }
                            }
                            timeLine = [...spots_info];
                            stampRallies = await getData({'type':'get_stamprally_info', 'id':stampRallies});
                            var k = 0;
                            for (var i = 0; i < spots_info.length; i++) {
                              print(i);
                              for (var j = 0; j < stampRallies.length; j++) {

                                if (spots_info[i]['stamp_rally'] == stampRallies[j]["id"]) {
                                  stampRallies[j]["is_stamp_rally"] = true;
                                  timeLine.insert(i, stampRallies[j]);
                                  k++;
                                }
                              }
                            }

                            for (var i = 0; i < timeLine.length; i++) {
                              images.add(await getImageUrl(timeLine[i]['image']));
                            }
                            print(timeLine);

                            setState(() {});

                          }
                        ),
                      ),
                  ],
                ),
              ),
            ),
          const SizedBox(height: 10,),
          Flexible(
            child: ListView.separated(
              itemCount: timeLine.length,
              itemBuilder: (context, int index) {
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  child: InkWell(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(10),


                          child: Image(image: CachedNetworkImageProvider(images[index]))
                        ),
                        const SizedBox(height: 6,),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 4.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(
                                timeLine[index]["title"],
                                style: const TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                )
                              ),
                              InkWell(
                                child: const Icon(Icons.library_books_outlined, color: Colors.grey, size: 25,),
                                onTap: () {

                                },
                              ),

                            ],
                          ),
                        ),
                        const SizedBox(height: 8,),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 4.0),
                          child: Text(
                            timeLine[index]["explanation"],
                            style: TextStyle(
                              fontSize: 13
                            ),
                            overflow: TextOverflow.ellipsis,
                            maxLines: 2,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(4),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Row(children: [
                                for (int i = 0; i < 5; i++)
                                  Icon(
                                    Icons.star,
                                    color: (i < timeLine[index]["star"].floor()) ? Colors.orange : Colors.grey,
                                  )
                              ],),
                              Text(timeLine[index]["star"].toString(), style: TextStyle(fontSize: 20),),
                              // const SizedBox(width: 15,),
                              // Icon(Icons.chat, color: Colors.grey, size: 17,),
                              // const SizedBox(width: 5,),
                              // Text("5000人", style: TextStyle(fontSize:14)),
                              const SizedBox(width: 15,),
                              Icon(Icons.bookmark, color: Colors.grey, size: 17,),
                              const SizedBox(width: 5,),
                              Text(timeLine[index]["bookmark"].toString(), style: TextStyle(fontSize:14))
                            ],
                          ),
                        ),
                        Row(
                          children: [
                            for (int i = 0; i < timeLine[index]["tag"].length; i++)
                            Padding(
                              padding: const EdgeInsets.symmetric(vertical:2, horizontal:5),
                              child: InkWell(
                                child: Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(999999),
                                    border: Border.all(color: Colors.blue),

                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(vertical:5, horizontal:12),
                                    child: Text(
                                      timeLine[index]["tag"][i],
                                      style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.blue,
                                      ),
                                    ),
                                  ),
                                ),
                                onTap: () {

                                },
                              ),
                            )
                          ],
                        )
                      ]
                    ),
                    onTap: () {
                      if (timeLine[index]["is_stamp_rally"])  {
                        Provider.of<ProjectInformationPageModel>(context, listen: false).updateStamprallyInfo(timeLine[index]);
                        Provider.of<ProjectInformationPageModel>(context, listen: false).updateImageUrl(images[index]);
                        Navigator.push(
                          context, MaterialPageRoute(
                            builder: (context) => ProjectInformationPage(),
                            // spotInfo: timeLine[index], imageUrl: images[index], reviewsList: []
                            //以下を追加
                            fullscreenDialog: true,
                          )
                        );
                      } else {
                        Provider.of<SpotInformationModel>(context, listen: false).updateSpotInfo(timeLine[index]);
                        Provider.of<SpotInformationModel>(context, listen: false).updateImageUrl(images[index]);
                        Navigator.push(
                          context, MaterialPageRoute(
                            builder: (context) => SpotInformationPage(),
                            //以下を追加
                            fullscreenDialog: true,
                          )
                        );
                      }
                    },
                  ),
                );
              },
              separatorBuilder: (context, index) {
                return const Padding(
                  padding: EdgeInsets.all(10),
                  child: Divider(
                    height: 1,

                  ),
                );
              },
            ),
          )

        ],
      ),

    );
  }
}