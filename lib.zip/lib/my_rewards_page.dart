import 'package:flutter/material.dart';
import 'package:stamprally_v2/rewards_list_model.dart';
import 'reward_page.dart';
import 'package:provider/provider.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:stamprally_v2/reward_model.dart';
class MyRewardsPage extends StatefulWidget {
  const MyRewardsPage({super.key});

  @override
  State<MyRewardsPage> createState() => _MyRewardsPageState();
}

class _MyRewardsPageState extends State<MyRewardsPage> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          elevation: 1,
          backgroundColor: Colors.white,
          centerTitle: true,
          title: Image.asset(
            'images/appBarImage.png',
            height: 38,
          ),
          bottom: TabBar(
            isScrollable: true,
            tabs: <Widget> [
              Tab(text: "未使用特典",),
              Tab(text: "受け取り可能特典",),
              Tab(text: "使用済み特典",),
            ],
          ),
        ),
        body: TabBarView(
          physics: NeverScrollableScrollPhysics(),
          children: [
            RewardsList(),
            RewardsList(),
            RewardsList(),
          ],
        ),
      ),
    );
  }
}


class RewardsList extends StatefulWidget {

  const RewardsList({super.key});

  @override
  State<RewardsList> createState() => _RewardsListState();
}

class _RewardsListState extends State<RewardsList> {


  @override
  Widget build(BuildContext context) {
    return Consumer<RewardsListModel>(builder: (context, model, child) {

      return Container(
        padding: const EdgeInsets.all(8.0),
        child: ListView.separated(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: model.rewardsList.length,
          itemBuilder: (context, int index) {
            return InkWell(
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical:6),
                child: Row(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          boxShadow: const [
                            BoxShadow(
                              color: Colors.grey, //色
                              spreadRadius: 0,
                              blurRadius: 3
                            ),
                          ],
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child:ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: model.imageUrlList[index] != ''
                            ? FittedBox(
                              fit: BoxFit.fitHeight,
                              child: Image(image: CachedNetworkImageProvider(model.imageUrlList[index]))
                            )
                            : const Center(child:CircularProgressIndicator())
                        ),
                        height: 80,
                        width: 80,
                      ),
                      Flexible(
                        child: Container(
                          padding: const EdgeInsets.only(left:15),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                model.rewardsList[index]["title"] != null
                                  ? model.rewardsList[index]["title"]
                                  : "...",
                                style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold
                                ),
                              ),
                              const SizedBox(height: 1,),
                              Text(
                                model.rewardsList[index]["conditions"] != null
                                  ? "応募条件: " + model.rewardsList[index]["conditions"]
                                  : "...",
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.grey,
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(2.0),
                                child: Text(
                                  model.rewardsList[index]["explanation"] != null
                                    ? model.rewardsList[index]["explanation"]
                                    : "...",
                                  style: TextStyle(
                                    fontSize: 13,
                                  ),
                                  overflow: TextOverflow.ellipsis,
                                  maxLines: 2,
                                ),
                              ),

                            ],
                          ),
                        ),
                      )
                    ]
                  ),
              ),
              onTap: () {
                Provider.of<RewardModel>(context, listen: false).updateRewardInfo(model.rewardsList[index]);
                Provider.of<RewardModel>(context, listen: false).updateImageUrl(model.imageUrlList[index]);
                Navigator.push(
                  context, MaterialPageRoute(
                    builder: (context) => RewardPage(),
                    //以下を追加
                    fullscreenDialog: true,
                  )
                );
              },
            );
          },
          separatorBuilder: (context, index) {
            return const Padding(
              padding: EdgeInsets.only(right: 10, left: 10),
              child: Divider(
                height: 1,

              ),
            );
          },
        ),

      );
    });
  }
}