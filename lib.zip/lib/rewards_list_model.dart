import 'package:flutter/material.dart';

class RewardsListModel extends ChangeNotifier {

  List rewardsList = [];
  List imageUrlList = [''];
  void updateRewardList(data) {
    rewardsList = data;
    notifyListeners();
  }
  void updateImageUrlList(data) {
    imageUrlList = data;
    notifyListeners();
  }

}